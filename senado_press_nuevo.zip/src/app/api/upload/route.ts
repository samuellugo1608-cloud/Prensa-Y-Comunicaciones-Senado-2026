import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/infrastructure/auth/session";
import { createServiceClient } from "@/infrastructure/supabase/client";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: "No se envió archivo" }, { status: 400 });
    }

    const allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (!allowed.includes(file.type)) {
      return NextResponse.json({ error: "Solo se permiten imágenes (JPG, PNG, WebP, GIF)" }, { status: 400 });
    }

    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: "La imagen no puede superar 5 MB" }, { status: 400 });
    }

    const supabase = createServiceClient();

    // La aplicación usa URLs públicas para que las imágenes puedan verse desde
    // el feed y desde el panel de administración. Si el bucket no existe se crea;
    // si existe pero es privado, se actualiza a público.
    const { data: bucket } = await supabase.storage.getBucket("post-images");
    if (!bucket) {
      const { error: bucketError } = await supabase.storage.createBucket("post-images", { public: true });
      if (bucketError && !/already exists/i.test(bucketError.message)) {
        return NextResponse.json({ error: "No se pudo configurar el almacenamiento de imágenes" }, { status: 500 });
      }
    } else if (!bucket.public) {
      const { error: updateBucketError } = await supabase.storage.updateBucket("post-images", { public: true });
      if (updateBucketError) {
        return NextResponse.json({ error: "El bucket de imágenes debe ser público" }, { status: 500 });
      }
    }

    const extensions: Record<string, string> = {
      "image/jpeg": "jpg",
      "image/png": "png",
      "image/webp": "webp",
      "image/gif": "gif",
    };
    const ext = extensions[file.type] ?? "jpg";
    const path = `${session.userId}/${crypto.randomUUID()}.${ext}`;

    const buffer = Buffer.from(await file.arrayBuffer());
    const { error } = await supabase.storage.from("post-images").upload(path, buffer, {
      contentType: file.type,
      upsert: false,
    });

    if (error) {
      return NextResponse.json({ error: "Error al subir imagen: " + error.message }, { status: 500 });
    }

    const { data: urlData } = supabase.storage.from("post-images").getPublicUrl(path);

    return NextResponse.json({ url: urlData.publicUrl });
  } catch (error) {
    console.error("Upload error:", error);
    return NextResponse.json({ error: "Error al subir imagen" }, { status: 500 });
  }
}