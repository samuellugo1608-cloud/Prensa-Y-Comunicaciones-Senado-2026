import { IModerationService, ModerationResult } from "@/domain/services/IModerationService";

const BANNED_WORDS = [
  "puta", "puto", "mierda", "hijueputa", "hijo de puta", "marica", "gonorrea",
  "imbécil", "imbecil", "estúpido", "estupido", "idiota", "pendejo", "culero",
  "carajo", "verga", "chingada", "chingado", "joder", "coño", "cono",
  "malparido", "hp", "mk", "mka", "ptm", "ctm", "fuck", "shit", "bitch",
  "asshole", "damn", "bastard", "cabrón", "cabron", "zorra", "perra",
  "asqueroso", "asco", "basura humana", "retardado", "retrasado",
];

const SUSPICIOUS_PATTERNS = [
  /\b(kill|matar|muerte a)\b/i,
  /\b(odio|hate)\s+(a|al|a la)\b/i,
];

// Heurística deliberadamente conservadora: no pretende identificar IA con certeza.
// Solo rechaza textos con señales muy fuertes y deja los casos ambiguos a revisión humana.
const STRONG_AI_PATTERNS = [
  /como modelo de lenguaje/i,
  /como inteligencia artificial/i,
  /como ia\b/i,
  /no puedo (ayudarte|responder|realizar)/i,
  /mi conocimiento se basa/i,
  /en conclusión,? (podemos|es importante|cabe destacar)/i,
];

const AI_STYLE_MARKERS = [
  /\b(en primer lugar|en segundo lugar|finalmente)\b/gi,
  /\b(cabe destacar|es importante señalar|en este sentido|por otro lado)\b/gi,
  /\b(sin lugar a dudas|en última instancia)\b/gi,
];

const CONSTRUCTIVE_MARKERS = [
  /\b(propongo|sugiero|recomiendo|sería mejor|podría|debería)\b/i,
  /\b(porque|debido a|por qué|razón|evidencia|dato|fuente|argumento)\b/i,
  /\b(alternativa|solución|mejora|corregir|aclarar|explicar|precisar)\b/i,
  /\?/, 
];

export class SpanishModerationService implements IModerationService {
  moderate(content: string): ModerationResult {
    const normalized = content
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

    const flaggedWords: string[] = [];

    for (const word of BANNED_WORDS) {
      const normalizedWord = word.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      const pattern = new RegExp(`\\b${normalizedWord.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\$&")}\\b`, "i");
      if (pattern.test(normalized) || normalized.includes(normalizedWord)) flaggedWords.push(word);
    }

    for (const pattern of SUSPICIOUS_PATTERNS) {
      if (pattern.test(content)) flaggedWords.push("contenido_sospechoso");
    }

    const letters = content.match(/[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g) ?? [];
    const upperLetters = content.match(/[A-ZÁÉÍÓÚÜÑ]/g) ?? [];
    if (letters.length > 20 && upperLetters.length / letters.length > 0.6) flaggedWords.push("mayusculas_excesivas");

    const strongAiSignals = STRONG_AI_PATTERNS.filter((pattern) => pattern.test(content)).length;
    const styleSignals = AI_STYLE_MARKERS.reduce((total, pattern) => total + (content.match(pattern)?.length ?? 0), 0);
    const longStructuredText = content.length >= 500 && /\n\s*[-•]/.test(content);
    const aiRisk: "low" | "high" = strongAiSignals >= 1 || (styleSignals >= 4 && longStructuredText) ? "high" : "low";

    const constructive = CONSTRUCTIVE_MARKERS.some((pattern) => pattern.test(content));
    const isClean = flaggedWords.length === 0;

    let reason: string | null = null;
    if (aiRisk === "high") reason = "Texto con señales fuertes de generación automática; rechazado.";
    else if (!isClean) reason = `Contenido marcado para revisión: ${flaggedWords.slice(0, 3).join(", ")}`;
    else if (!constructive) reason = "Comentario pendiente de revisión por falta de elementos constructivos.";

    return { isClean, flaggedWords, reason, aiRisk, constructive };
  }
}
