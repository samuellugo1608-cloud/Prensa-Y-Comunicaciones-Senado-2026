export interface ModerationResult {
  isClean: boolean;
  flaggedWords: string[];
  reason: string | null;
  aiRisk: "low" | "high";
  constructive: boolean;
}

export interface IModerationService {
  moderate(content: string): ModerationResult;
}
