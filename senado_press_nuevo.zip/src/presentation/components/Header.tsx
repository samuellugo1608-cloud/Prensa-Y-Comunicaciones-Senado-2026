"use client";

import Image from "next/image";
import { LogOut, Shield } from "lucide-react";
import { useRouter } from "next/navigation";
import { SessionPayload } from "@/infrastructure/auth/session";

interface HeaderProps {
  user: SessionPayload;
}

export function Header({ user }: HeaderProps) {
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  return (
    <header className="gradient-header text-white">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4 min-w-0">
          <Image
            src="/images/logo-senado.png"
            alt="Logo del Senado"
            width={160}
            height={160}
            priority
          />
          <div className="min-w-0">
            <h1 className="font-display text-xl font-bold tracking-tight">Senado Press</h1>
            <p className="text-senate-200 text-xs">Sala de Prensa — BIMUN 2026</p>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-6 text-sm text-senate-200">
          <div className="text-center">
            <p className="text-senate-300 text-xs uppercase tracking-wider">Presidente</p>
            <p className="font-medium text-white">Sophia Hamburguer</p>
          </div>
          <div className="w-px h-8 bg-senate-600" />
          <div className="text-center">
            <p className="text-senate-300 text-xs uppercase tracking-wider">Vicepresidenta</p>
            <p className="font-medium text-white">Valeria Gómez</p>
          </div>
          <div className="w-px h-8 bg-senate-600" />
          <div className="text-center">
            <p className="text-senate-300 text-xs uppercase tracking-wider">Secretario General</p>
            <p className="font-medium text-white">Samuel Lugo</p>
          </div>
          <div className="w-px h-8 bg-senate-600" />
          <div className="text-center">
            <p className="text-senate-300 text-xs uppercase tracking-wider">Sub Secretaria</p>
            <p className="font-medium text-white">Mariana Mendez</p>
            <p className="text-[10px] text-senate-300">marianamendez@redboston.edu.co</p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium">{user.displayName}</p>
            <p className="text-xs text-senate-300">
              {user.role === "admin" ? (
                <span className="flex items-center gap-1 justify-end">
                  <Shield className="w-3 h-3" /> Administrador
                </span>
              ) : (
                user.mediaOutlet ?? "Periodista"
              )}
            </p>
          </div>
          <button
            onClick={handleLogout}
            className="p-2 rounded-lg hover:bg-white/10 transition-colors"
            title="Cerrar sesión"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
}