export function Footer() {
  return (
    <footer className="text-center py-6 text-xs text-gray-400 border-t border-gray-200/60 mt-8">
      <p>Senado Press — Modelo de Senado BIMUN 2026</p>
      <p className="mt-1">
        Mesa Directiva: Sophia Hamburguer (Presidente) · Valeria Gómez (Vicepresidenta) · Samuel Lugo (Secretario General) · Mariana Mendez (Sub Secretaria)
      </p>
      <p className="mt-2 text-gray-300">
        Desarrollado por Alejandra Valencia
      </p>
    </footer>
  );
}