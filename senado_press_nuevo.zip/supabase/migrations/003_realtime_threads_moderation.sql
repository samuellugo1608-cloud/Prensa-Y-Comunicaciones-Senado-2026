-- Migración 003: tiempo real para publicaciones/comentarios.
-- Ejecutar en el SQL Editor de Supabase.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'posts'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.posts;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_posts_status_parent_created
  ON posts(status, parent_post_id, created_at DESC);
